
export interface NavItem {
  label: string;
  href: string;
}

export interface Pillar {
  title: string;
  description: string;
  icon: string;
  color: string;
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export interface EventDetails {
  title: string;
  organization: string;
  host: string;
  hostTitle: string;
  date: string;
  time: string;
  location: string;
  theme: string;
  contacts: string[];
}
