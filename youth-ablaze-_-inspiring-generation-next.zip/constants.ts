
import { NavItem, Pillar, EventDetails } from './types';

export const NAV_ITEMS: NavItem[] = [
  { label: 'Home', href: '#home' },
  { label: 'The Artists', href: '#artists' },
  { label: 'The Vision', href: '#vision' },
  { label: 'The Host', href: '#host' },
  { label: 'Registration', href: '#register' },
];

export const ARTISTS = [
  { name: 'Hiro Lyon', role: 'LMAM Artist', image: 'https://images.unsplash.com/photo-1520127877030-94fa651d0b4e?auto=format&fit=crop&q=80&w=400' },
  { name: 'Daniel Myles', role: 'LMAM Artist', image: 'https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?auto=format&fit=crop&q=80&w=400' },
  { name: 'Melvin Wonder', role: 'LMAM Artist', image: 'https://images.unsplash.com/photo-1514525253361-b83a85f089c2?auto=format&fit=crop&q=80&w=400' }
];

export const PILLARS: Pillar[] = [
  {
    title: 'Spiritual Fire',
    description: 'Igniting a deep, personal relationship with God that burns with passion and purpose.',
    icon: 'Flame',
    color: 'from-orange-500 to-red-600'
  },
  {
    title: 'Global Leadership',
    description: 'Developing the mentality of a world-changer within the Believer\'s Loveworld vision.',
    icon: 'Crown',
    color: 'from-blue-500 to-cyan-400'
  },
  {
    title: 'Academic Excellence',
    description: 'Empowering students to lead in their fields at UNIBEN and beyond.',
    icon: 'GraduationCap',
    color: 'from-yellow-400 to-orange-500'
  },
  {
    title: 'Creative Arts',
    description: 'Showcasing talent through the LMAM stage in music, dance, and more.',
    icon: 'Music',
    color: 'from-purple-500 to-pink-500'
  }
];

export const EVENT_INFO: EventDetails = {
  title: 'YOUTH ABLAZE',
  organization: "BELIEVER'S LOVEWORLD ZONE J, UNIBEN",
  host: 'PASTOR JOHN JIBRIL',
  hostTitle: 'Highly Esteemed Zonal Secretary',
  date: 'THUR. 5TH MARCH, 2026',
  time: '4:00 PM PROMPT',
  location: 'OUTSIDE FESTUS IYAYI HALL OPPOSITE HALL 2, UNIBEN',
  theme: 'Inspiring Generation Next',
  contacts: ['09134991814', '08061161865']
};
