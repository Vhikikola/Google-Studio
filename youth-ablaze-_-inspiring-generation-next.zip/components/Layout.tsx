
import React, { useState, useEffect } from 'react';
import { Menu, X, Flame, Phone } from 'lucide-react';
import { NAV_ITEMS, EVENT_INFO } from '../constants';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-slate-950">
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-slate-950/95 backdrop-blur-md py-4 border-b border-white/10' : 'bg-transparent py-6'
      }`}>
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
          <div className="flex items-center gap-3 group cursor-pointer">
            <div className="w-10 h-10 bg-yellow-400 rounded-lg flex items-center justify-center rotate-3 group-hover:rotate-0 transition-transform">
              <Flame className="w-6 h-6 text-slate-950 fill-current" />
            </div>
            <div className="flex flex-col">
              <span className="font-heading font-black text-xl tracking-tighter leading-none">{EVENT_INFO.title}</span>
              <span className="text-[10px] font-bold text-cyan-400 tracking-widest uppercase">Generation Next</span>
            </div>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex gap-10">
            {NAV_ITEMS.map((item) => (
              <a 
                key={item.label} 
                href={item.href}
                className="text-slate-300 hover:text-cyan-400 transition-colors font-black uppercase text-xs tracking-widest"
              >
                {item.label}
              </a>
            ))}
          </div>

          <button className="md:hidden text-white" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden absolute top-full left-0 right-0 bg-slate-900 border-b border-white/10 p-6 space-y-4 shadow-2xl">
            {NAV_ITEMS.map((item) => (
              <a 
                key={item.label} 
                href={item.href}
                onClick={() => setMobileMenuOpen(false)}
                className="block text-xl font-black text-slate-300 hover:text-cyan-400 uppercase tracking-tighter"
              >
                {item.label}
              </a>
            ))}
          </div>
        )}
      </nav>

      <main>{children}</main>

      <footer className="bg-slate-950 border-t border-white/5 py-16 px-6">
        <div className="max-w-7xl mx-auto grid md:grid-cols-3 gap-12">
          <div className="space-y-6 text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-3">
              <div className="w-8 h-8 bg-yellow-400 rounded flex items-center justify-center">
                <Flame className="w-5 h-5 text-slate-950 fill-current" />
              </div>
              <span className="font-heading font-black tracking-tighter text-lg">{EVENT_INFO.title}</span>
            </div>
            <p className="text-slate-400 font-medium leading-relaxed">
              {EVENT_INFO.organization}. Join the next generation of world changers.
            </p>
          </div>
          
          <div className="space-y-6 text-center md:text-left">
            <h4 className="text-white font-black uppercase tracking-widest text-sm">Quick Links</h4>
            <div className="flex flex-col gap-3">
              {NAV_ITEMS.map(item => (
                <a key={item.label} href={item.href} className="text-slate-500 hover:text-cyan-400 transition-colors font-bold uppercase text-xs tracking-widest">{item.label}</a>
              ))}
            </div>
          </div>

          <div className="space-y-6 text-center md:text-left">
            <h4 className="text-white font-black uppercase tracking-widest text-sm">Enquiries</h4>
            <div className="space-y-4">
              {/* Fixed: Added Phone icon from lucide-react */}
              {EVENT_INFO.contacts.map(c => (
                <div key={c} className="flex items-center justify-center md:justify-start gap-3 text-slate-400">
                  <Phone className="w-4 h-4 text-cyan-400" />
                  <span className="font-bold">{c}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        <div className="max-w-7xl mx-auto mt-16 pt-8 border-t border-white/5 text-center">
          <p className="text-slate-500 text-xs font-bold tracking-widest uppercase">
            © 2026 {EVENT_INFO.title} (INSPIRING GENERATION NEXT). ALL RIGHTS RESERVED.
          </p>
        </div>
      </footer>
    </div>
  );
};
