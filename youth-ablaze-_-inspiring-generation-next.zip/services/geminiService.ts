
import { GoogleGenAI } from "@google/genai";
import { EVENT_INFO, ARTISTS } from "../constants";

// Fixed: Initialization must use process.env.API_KEY directly as a named parameter.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getAblazeResponse = async (userMessage: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: userMessage,
      config: {
        systemInstruction: `You are the digital assistant for "${EVENT_INFO.title} (Inspiring Generation Next)", organized by ${EVENT_INFO.organization}.
        
        Key Details to mention:
        - Host: ${EVENT_INFO.host} (${EVENT_INFO.hostTitle}).
        - Date: ${EVENT_INFO.date}.
        - Time: ${EVENT_INFO.time}.
        - Exact Venue: ${EVENT_INFO.location}.
        - Special Guests: Featuring LMAM artists ${ARTISTS.map(a => a.name).join(', ')}.
        - Special Info: Admission is FREE. FREE BUS AVAILABLE.
        - Enquiries: ${EVENT_INFO.contacts.join(' or ')}.
        
        Your tone: High energy, fire-inspired, spiritual yet very cool and youthful. 
        Focus on the "Generation Next" theme and the musical impact of the LMAM guests. 
        Encourage everyone to come for the 4:00 PM prompt start outside Festus Iyayi Hall.`,
        temperature: 0.7,
      },
    });

    // Fixed: Always access response.text property directly.
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "I'm having a little trouble connecting right now, but we'd love to see you for Youth Ablaze on March 5th, 2026 at 4:00 PM Prompt outside Festus Iyayi Hall!";
  }
};
