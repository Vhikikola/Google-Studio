
import React from 'react';
import { Layout } from './components/Layout';
import { PILLARS, EVENT_INFO, ARTISTS } from './constants';
import { AblazeAssistant } from './components/AblazeAssistant';
import { Calendar, MapPin, Clock, Flame, Crown, GraduationCap, Music, ArrowRight, Bus, Phone, Info, Star } from 'lucide-react';

const App: React.FC = () => {
  const iconMap: Record<string, any> = {
    Flame: Flame,
    Crown: Crown,
    GraduationCap: GraduationCap,
    Music: Music,
  };

  return (
    <Layout>
      {/* Hero Section */}
      <section id="home" className="relative pt-32 pb-20 md:pt-48 md:pb-32 px-6 overflow-hidden bg-festival-blue">
        <div className="absolute top-0 left-0 w-full h-full -z-10 opacity-30">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500 rounded-full blur-[120px]"></div>
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-orange-500 rounded-full blur-[120px]"></div>
        </div>
        
        <div className="max-w-7xl mx-auto text-center relative z-10">
          <div className="inline-block mb-6">
            <h3 className="text-cyan-400 font-heading font-bold tracking-widest text-sm md:text-base border-b-2 border-cyan-400 pb-1 mb-2 uppercase">
              {EVENT_INFO.organization}
            </h3>
            <p className="text-white/80 text-xs font-bold uppercase tracking-[0.3em]">Nigeria Region</p>
          </div>
          
          <h1 className="text-6xl md:text-9xl font-heading font-black mb-4 leading-none tracking-tighter">
            <span className="block text-white">YOUTH</span>
            <span className="block gradient-festival text-3d">ABLAZE</span>
            <span className="block text-cyan-400 text-lg md:text-2xl mt-4 font-bold tracking-[0.4em] uppercase">
              (Inspiring Generation Next)
            </span>
          </h1>
          
          <div className="mt-8 mb-10 inline-flex flex-col items-center">
             <p className="text-xl md:text-2xl text-slate-200 font-semibold mb-2 italic">
               WITH THE HIGHLY ESTEEMED ZONAL SECRETARY
             </p>
             <h2 className="text-2xl md:text-5xl font-black text-white uppercase tracking-tight ablaze-glow px-6 py-2 rounded-xl bg-white/5">
               {EVENT_INFO.host}
             </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto mb-16">
            <div className="flex flex-col items-center bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20">
              <Calendar className="w-8 h-8 text-yellow-400 mb-2" />
              <p className="text-xs uppercase font-bold text-white/60">Date</p>
              <p className="text-xl font-black text-white">{EVENT_INFO.date}</p>
            </div>
            <div className="flex flex-col items-center bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20">
              <Clock className="w-8 h-8 text-cyan-400 mb-2" />
              <p className="text-xs uppercase font-bold text-white/60">Time</p>
              <p className="text-xl font-black text-white">{EVENT_INFO.time}</p>
            </div>
            <div className="flex flex-col items-center bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20">
              <MapPin className="w-8 h-8 text-orange-500 mb-2" />
              <p className="text-xs uppercase font-bold text-white/60">Venue</p>
              <p className="text-sm font-black text-white leading-tight">OUTSIDE FESTUS IYAYI HALL <br/> OPP. HALL 2, UNIVERSITY OF BENIN</p>
            </div>
          </div>

          <div className="flex flex-wrap justify-center gap-4">
            <a 
              href="#register" 
              className="inline-flex items-center gap-3 px-10 py-5 bg-yellow-400 text-slate-950 font-black rounded-full text-xl shadow-2xl hover:bg-yellow-300 transition-all hover:scale-105 uppercase tracking-tighter"
            >
              Get Free Entry <ArrowRight className="w-6 h-6" />
            </a>
            <div className="bus-badge inline-flex items-center gap-2 px-6 py-4 bg-cyan-500 text-slate-950 font-black rounded-full text-lg shadow-xl uppercase tracking-tighter">
              <Bus className="w-6 h-6" /> Free Bus Available
            </div>
          </div>
        </div>
      </section>

      {/* Guest Artists Section */}
      <section id="artists" className="py-24 px-6 bg-slate-950 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-[100px]"></div>
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="text-center mb-16">
             <div className="inline-flex items-center gap-2 text-yellow-400 mb-4">
               <Star className="w-5 h-5 fill-current" />
               <span className="font-bold uppercase tracking-[0.3em]">Featuring LMAM Artists</span>
               <Star className="w-5 h-5 fill-current" />
             </div>
             <h2 className="text-4xl md:text-6xl font-heading font-black mb-4">GOSPEL STARS</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {ARTISTS.map((artist) => (
              <div key={artist.name} className="group relative">
                <div className="relative aspect-square overflow-hidden rounded-3xl border-4 border-white/10 group-hover:border-cyan-400 transition-all">
                  <img 
                    src={artist.image} 
                    alt={artist.name} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 to-transparent opacity-80"></div>
                  <div className="absolute bottom-6 left-6 right-6">
                    <h4 className="text-2xl font-black text-white">{artist.name}</h4>
                    <p className="text-cyan-400 font-bold uppercase text-xs tracking-widest">{artist.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Vision & Pillars */}
      <section id="vision" className="py-24 px-6 relative bg-slate-900/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-6xl font-heading font-black mb-4">THE FIRE WITHIN</h2>
            <p className="text-slate-400 max-w-2xl mx-auto text-lg">
              Generation Next is rising. Youth Ablaze is the catalyst for your spiritual and mental transformation.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {PILLARS.map((pillar) => {
              const Icon = iconMap[pillar.icon];
              return (
                <div key={pillar.title} className="p-8 rounded-2xl bg-slate-900 border border-slate-800 hover:border-cyan-500/50 transition-all group">
                  <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${pillar.color} flex items-center justify-center mb-6 text-white group-hover:rotate-12 transition-transform shadow-xl`}>
                    <Icon className="w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-black mb-4 text-white uppercase">{pillar.title}</h3>
                  <p className="text-slate-400 leading-relaxed font-medium">
                    {pillar.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Registration Section */}
      <section id="register" className="py-24 px-6 bg-slate-900">
        <div className="max-w-4xl mx-auto bg-slate-950 border-4 border-cyan-500/30 rounded-[3rem] p-8 md:p-16 shadow-2xl relative">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-heading font-black mb-4 uppercase">Secure Your Spot</h2>
            <p className="text-slate-400 font-bold uppercase tracking-widest text-sm">FREE ADMISSION • FREE BUS • UNLIMITED IMPACT</p>
          </div>

          <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
            <div className="grid md:grid-cols-2 gap-6">
              <input type="text" className="w-full bg-slate-900 border-2 border-slate-800 rounded-2xl p-5 focus:outline-none focus:border-cyan-500 text-white font-bold" placeholder="Full Name" />
              <input type="email" className="w-full bg-slate-900 border-2 border-slate-800 rounded-2xl p-5 focus:outline-none focus:border-cyan-500 text-white font-bold" placeholder="Email Address" />
            </div>
            <div className="grid md:grid-cols-2 gap-6">
              <input type="tel" className="w-full bg-slate-900 border-2 border-slate-800 rounded-2xl p-5 focus:outline-none focus:border-cyan-500 text-white font-bold" placeholder="Phone Number" />
              <select className="w-full bg-slate-900 border-2 border-slate-800 rounded-2xl p-5 focus:outline-none focus:border-cyan-500 text-white font-bold">
                <option>Interested in Free Bus?</option>
                <option>Yes, I'm coming with the bus</option>
                <option>No, I will find my way</option>
              </select>
            </div>
            <button className="w-full py-6 bg-cyan-500 text-slate-950 rounded-2xl font-black text-2xl shadow-xl hover:bg-cyan-400 transition-all uppercase tracking-tighter">
              Register for Youth Ablaze
            </button>
          </form>
        </div>
      </section>

      {/* Gemini Assistant Component */}
      <AblazeAssistant />
    </Layout>
  );
};

export default App;
